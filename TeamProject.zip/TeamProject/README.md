# team-project

Farrah Rodriguez,
Samuel Love,
John Ko,
Jacob Truman
